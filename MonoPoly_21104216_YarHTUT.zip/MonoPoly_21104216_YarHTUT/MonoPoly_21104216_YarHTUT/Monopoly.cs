﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class Monopoly : Game
    {
        public override void initializeGame()
        {

        }

        public override void makePlay(int PlayerIndex)
        {
          
        }
      public  override bool endGame()
        {
            return true;
        }
        public override void  printWinner()
      {

      }
    }
}
