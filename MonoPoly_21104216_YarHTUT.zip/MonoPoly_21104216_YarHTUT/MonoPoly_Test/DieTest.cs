﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using MonoPoly_21104216_YarHTUT;

namespace MonoPoly_Test
{
    [TestFixture]
    public class DieTest
    {
        [Test]
        public void TestDieRollRage()
        {
            Die die = new Die();
           // int roll = die.roll();
            for (int i = 0; i < 10000; i++ )
            {
                int roll = die.roll();
                Assert.LessOrEqual(roll, 6);
                Assert.GreaterOrEqual(roll, 1);
            }
                           

        }
        [Test]
        public void TestRandomnessOutputDieManyTime()
        {
            Die die = new Die();
            Console.WriteLine("Random Numbers:");
            for (int i = 0; i < 1000; i++ )
            {
                Console.WriteLine(die.roll().ToString());
            }
        }

        [Test]
        public void TestToSting()
        {
            Die die = new Die();
            int roll = die.roll();

            Assert.AreEqual(roll.ToString(), die.ToString());
        }
        /*
        [Test]
        public void TestRandom1Failing()
        {
            Die die = new Die();
            int NumberToTest = 1;
            int roll = die.roll();

            Assert.AreNotEqual(roll, NumberToTest);

            NumberToTest = roll;

        }
        [Test]
        public void TestRandom2Failing()
        {
            Die die = new Die();
            int NumberToTest = 2;
            int roll = die.roll();

            Assert.AreNotEqual(roll, NumberToTest);

            NumberToTest = roll;

        }
         * */


    }
}
