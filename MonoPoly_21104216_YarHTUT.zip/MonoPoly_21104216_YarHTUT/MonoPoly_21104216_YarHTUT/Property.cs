﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class Property
    {
        protected string sName;
        protected Trader owner;
        public Property()
        {

        }

        public Property(string sName)
        {
            this.sName = sName;
        }
        public Property(string sName, ref Trader owner)
        {
            this.sName = sName;
            this.owner = owner;
        }
        public Trader getOwner()
        {
            return this.owner;
        }
        public void setOwner(ref Player newOwner)
        {
            this.owner = newOwner;
        }
        public void setOwner(ref Banker newOwner)
        {
            this.owner = newOwner;
        }
        public string getName()
        {
            return this.sName;
        }
        public virtual bool availableForPurchase()
        {
            return false;
        }
        public virtual string landOn(ref Player player)
        {
            return string.Format("{0} landed On {1}",player.getName(),this.getName());
        }
        public override string ToString()
        {
            return 
                String.Format("{0} : \t Owned by : {1}",
                this.getName(), this.getOwner().getName());
        }


    }
}
