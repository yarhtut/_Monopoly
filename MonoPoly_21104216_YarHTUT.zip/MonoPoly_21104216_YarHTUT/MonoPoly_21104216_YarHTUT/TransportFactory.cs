﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class TransportFactory: TradeableProperty

    {
        public Transport create(string sName)
        {
            return new Transport(sName);
        }
    }
}
