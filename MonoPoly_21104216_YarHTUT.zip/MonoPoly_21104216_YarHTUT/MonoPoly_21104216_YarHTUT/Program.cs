﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
