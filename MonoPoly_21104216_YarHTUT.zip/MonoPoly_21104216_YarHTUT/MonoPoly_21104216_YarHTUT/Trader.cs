﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
   public class Trader
    {
        protected ArrayList propertiesOwned = new ArrayList();
        protected decimal dBalance;
        protected string sName;

        public Trader()
        {

        }
        public Trader(string sName, decimal dBalance)
        {
            this.sName = sName;
            this.dBalance = dBalance;

        }
        public decimal getBalance()
        {
            return dBalance;

        }
        public void setBalance(decimal dBalance)
        {
            this.dBalance = dBalance;
        }

        public string getName()
        {
            return sName;
        }
        public void setName(string sName)
        {
            this.sName = sName;
        }
        public void checkbankrupt()
        {
            if (this.getBalance() <= 0)
            {
                throw new ApplicationException(string.Format("{0} is now Bankrupt.\n balance:{1}", this.getName(), this.getBalance()));
            } 
        }
        public override string ToString()
        {
            return String.Format("Name: {0} \nBalance: {1}", this.getName(), this.getBalance());
        }
        public void pay(decimal dAmount)
        {
            this.dBalance -= dAmount;
            checkbankrupt();

        }
        public void receive(decimal dAmount)
        {
            this.dBalance += dAmount;
        }
        public void obtainProperty(ref Property property)
        {
            this.propertiesOwned.Add(property);
        }
        public void tradeProperty(ref TradeableProperty property,ref Player purchaser, decimal amount)
        {
            purchaser.pay(amount);
            this.receive(amount);
            property.setOwner(ref purchaser);
        }

        internal ArrayList getPropertiesOwnedToString()
        {
            return this.propertiesOwned;
        }
    }
}
