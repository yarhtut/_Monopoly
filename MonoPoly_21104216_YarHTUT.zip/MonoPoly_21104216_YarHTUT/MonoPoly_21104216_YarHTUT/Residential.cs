﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class Residential:TradeableProperty
    {
        decimal dHouseCost;
        int iHouses;
        static int iMaxHouses = 4;
        //hotel to be impolemented 

        public Residential() : this("Residential Property") { }
        public Residential (string sName) : this(sName,200,50,50) {}

        public Residential(String sName, decimal dPrice, decimal dRent, decimal dHouseCost)
        {
            this.sName = sName;
            this.dPrice = dPrice;
            this.dRent = dRent;
            this.dMortgageValue = dPrice / 2;
            this.dHouseCost = dHouseCost;
        }
        public override decimal getRent()
        {
            return (dRent + (dRent * iHouses));
        }
        public  void addHouse()
        {
            this.getOwner().pay(this.dHouseCost);
            this.iHouses += 1;

        }
        public decimal getHouseCost()
        {
            return this.dHouseCost;
        }
        public int getHouseCount()
        {
            return this.iHouses;
        }
        public static int getMaxHouses()
        {
            return iMaxHouses;
        }

        public override string ToString()
        {
            return base.ToString() + string.Format("\t Houses:{0}", this.getHouseCount());
        }


    }
}
