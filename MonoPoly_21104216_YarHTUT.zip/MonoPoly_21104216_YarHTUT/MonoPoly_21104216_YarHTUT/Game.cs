﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
   
        public abstract class Game: GameInterface
        {
            private int PlayerCount;
           
            public abstract void initializeGame();
            public abstract bool endGame();
            public abstract void  makePlay(int player);
           // public abstract void playOneGame(int PlayerCount);

            public abstract void printWinner();


            public void playOneGame(int PlayerCount)
            {
                this.PlayerCount = PlayerCount;
                initializeGame();

                int j = 0;
                while(!endGame())
                {
                    makePlay(j);

                    j = (j + 1);
                }
                printWinner();
            }

           
        
    }
}
