﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class UtilityFactory:PropertyFactory
    {
        public Utility create (string sName)
        {
            return new Utility(sName);
        }
    }
}
