﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MonoPoly_21104216_YarHTUT
{
    public class Banker: Trader
    {
        static Banker banker;
        public Banker()
        {
            this.setName("Banker");
            this.setBalance(InitialValueaccessor.getBankerStartingBalance());
        }
        public static Banker access()
        {
            if (banker == null)
            {
                banker = new Banker();
            }     
            return banker;            
        }
    }
}
