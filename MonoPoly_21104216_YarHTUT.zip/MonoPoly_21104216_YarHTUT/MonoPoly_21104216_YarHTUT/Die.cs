﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class Die
    {
        private static Random numGenerator = new Random();
        private int numberrolled;

        public int roll()
        {
            numberrolled = numGenerator.Next(1, 7);
            return numberrolled;
        }
        public int numberLastRolled()
        {
            return numberrolled;
        }

        public override string ToString()
        {
            return numberrolled.ToString();
        }
    }
}
