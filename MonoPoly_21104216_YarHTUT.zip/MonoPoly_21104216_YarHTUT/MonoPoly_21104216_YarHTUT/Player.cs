﻿using System;
using System.Collections;
using System.Linq;
using System.Text;

namespace MonoPoly_21104216_YarHTUT
{
    public class Player : Trader
    {
        private int location;
        private int lastMove;


        Die die1 = new Die();
        Die die2 = new Die();

        bool active = true;

        public event EventHandler playerPassGo;
        public event EventHandler playerBankrupt;

        public Player(string sName)
        {
            this.sName = sName;
            this.dBalance = InitialValueaccessor.getPlayerStartingBalance();
            this.location = 0;

        }
        public void move()
        {
           // die1.roll();
           // die2.roll();

            int iMoveDistance = die1.roll() + die2.roll();

            this.setLocation(this.getLocation() + iMoveDistance);
            this.lastMove = iMoveDistance;
        }
        public int getLastMove()
        {
            return this.lastMove;
        }
        public int getLocation()
        {
            return this.location;
        }
        public void setLocation(int location)
        {
            if (location >= Board.access().getSquares())
            {
                location = location - Board.access().getSquares();
                if (playerPassGo != null)
                {
                    this.playerPassGo(this, new EventArgs());
                    this.receive(200);
                }
            }
            this.location = location;
        }
        public override string ToString()
        {
            return this.getName();
        }
        public  string BriefDetailToString()
        {
            return 
                string.Format("Your are on {0}. \t You have ${1}",
                Board.access().getProperty(this.getLocation()).getName()
                ,this.getBalance());
        }
        public  string FullDetailToString()
        {
            return
                string.Format("Player: {0}.\nBalance:${1}\nLocation:{2} (Square {3}) \nProperties Owned: \n{4}",
                this.getName(), this.getBalance(), Board.access().getProperty(this.getLocation()), this.getLocation(), this.getPropertiesOwnedToString()
                );
        }
        public string diceRollingToString()
        {
            return 
                string.Format("Rolling dice : \t Dice 1 : {0} \t Dice 2 :{1}",
                die1,die2
                );
        }
        public  void checkBankrupt()
        {
            if (this.getBalance() <= 0)
            {
                if (playerBankrupt != null)
                {
                    this.playerBankrupt(this, new EventArgs());
                    Banker b = Banker.access();
                    foreach (Property p in this.getPropertiesOwnedFromBoard())
                    {
                        p.setOwner(ref b);
                    }
                }
                this.active = false;
            }
        }

        /*
        public  string ToString()
        {
            return this.getName();
        }
        */
        public bool isNotActive()
        {
            return this.active;
        }
        public ArrayList getPropertiesOwnedFromBoard()
             {
                 ArrayList propertiesOwned = new ArrayList();

                 for (int i = 0; i < Board.access().getProperties().Count; i++)
                   {
                      if(Board.access().getProperty(i).getOwner() == this)
                       {
                          propertiesOwned.Add(Board.access().getProperty(i));
                       }
                    }
                        return propertiesOwned;
                }
        
       

    }
}
