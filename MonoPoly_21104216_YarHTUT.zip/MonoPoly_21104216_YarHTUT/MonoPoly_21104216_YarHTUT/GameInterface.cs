﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    interface GameInterface
    {
     
        bool endGame();
        void initializeGame();
        void makePlay(int player);
        void playOneGame(int PlayerCount);
        void printWinner();

    }
}
