﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
   public static class InitialValueaccessor
    {
        static public decimal getBankerStartingBalance()
        {
            return 100000;
        }
        static public decimal getPlayerStartingBalance()
        {
            return 1500;
        }
    }
}
