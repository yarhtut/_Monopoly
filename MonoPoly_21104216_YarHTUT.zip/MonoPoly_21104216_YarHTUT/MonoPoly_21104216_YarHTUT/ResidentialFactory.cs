﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class ResidentialFactory : PropertyFactory
    {
        public Residential create(string sName,decimal dPrice, decimal dRent , decimal dHouseCost)
        {
            return new (sName, dPrice, dRent, dHouseCost);
        }
    }
}
