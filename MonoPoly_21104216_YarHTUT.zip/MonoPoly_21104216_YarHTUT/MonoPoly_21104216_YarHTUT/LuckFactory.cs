﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class LuckFactory: PropertyFactory
    {
        public luck create(string sName, bool isPenalty, decimal dAmount)
        {
            return new luck(sName, isPenalty, dAmount);
        }
    }
}
