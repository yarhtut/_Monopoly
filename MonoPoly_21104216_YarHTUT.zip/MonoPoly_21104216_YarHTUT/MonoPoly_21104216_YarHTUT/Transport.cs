﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class Transport:TradeableProperty
    {

        public Transport() : this("Railway Station") { }

        public Transport(string sName)
        {
            this.sName = sName;
            this.dPrice = 200;
            this.dMortgageValue = 100;
            this.dRent = 50;
            this.owner = Banker.access();
            
        }
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
