﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonoPoly_21104216_YarHTUT
{
    public class Board
    {
        static Board board;
        private ArrayList properties;
        private ArrayList players;
        int Squares = 40;


        //Singleton method to access
        public static Board access()
        {
            if(board == null)
            {
                board = new Board();
               
            }
            return board;
        }
        public Board()
        {
            properties = new ArrayList(this.getSquares());
            players = new ArrayList();
        }
        public int getSquares()
        {
            return Squares;
        }
        public Property getProperty (int propIndex)
        {
            return (Property)properties[propIndex];
        }
        public ArrayList getProperties()
        {
            return this.properties;
        }
        public ArrayList getPlayers()
        {
            return this.players;
        }
        public Player getPlayer(string name)
        {
            foreach(Player player in players)
            {
                if (player.getName() == name)
                    return player;
            }
            return null;
        }
        public void addPlayer(Player player)
        {
            players.Add(player);
        }
        public void addPropert(Property property)
        {
            properties.Add(property);
        }

        public int getPlayerCount()
        {
            return players.Count;
        }

        public override string ToString()
        {
            throw new System.NotImplementedException();
        }
    }
}
